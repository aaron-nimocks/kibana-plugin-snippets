import React, { useEffect, useState } from 'react';
import { i18n } from '@kbn/i18n';
import { FormattedMessage, I18nProvider } from '@kbn/i18n/react';
import { BrowserRouter as Router } from 'react-router-dom';
import { CoreStart } from '../../../../src/core/public';

import {
  EuiInMemoryTable
} from '@elastic/eui';
import moment from 'moment';

interface ICustomStylesTable {
  notifications?: CoreStart['notifications'];
  http: CoreStart['http'];
}

export const CustomStylesTable = ({
  notifications,
  http
}: ICustomStylesTable) => {
  // Use React hooks to manage state.

  const [tableData, setTableData] = useState<any>([]);

  useEffect(() => {
    http.get('/api/custom_styles/get_table').then((res) => {
      let tableDataArray: String[] = Object.values(res);
      setTableData(tableDataArray[0]);
    });
  }, []);

  const columns = [
    {
      field: '_source.name',
      name: 'Style Name',
      sortable: true,
    },
    {
      field: '_source.application',
      name: 'Application',
      sortable: true,
    },
    {
      field: '_source.role',
      name: 'Role',
      sortable: true,
    },
    {
      field: '_source.user',
      name: 'User',
      sortable: true,
    },
    {
      field: '_source.timestamp',
      name: 'Last Updated',
      truncateText: true,
    }
  ];

  console.log(tableData);

  // Render the application DOM.
  // Note that `navigation.ui.TopNavMenu` is a stateful component exported on the `navigation` plugin's start contract.
  return (
    <EuiInMemoryTable
      items={tableData}
      columns={columns}
      pagination={true}
    />
  );
};
