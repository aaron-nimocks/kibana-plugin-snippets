export const PLUGIN_ID = 'customStyles';
export const PLUGIN_NAME = 'customStyles';
