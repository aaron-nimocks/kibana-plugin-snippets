import { IRouter } from '../../../../src/core/server';

export function registerCheckIndexRoute(router: IRouter) {
    router.get(
        {
            path: '/api/custom_styles/check_index',
            validate: {
            },
        },
        async (context, request, response) => {

            const requestClient = context.core.elasticsearch.client.asCurrentUser;

            const { body: index_exists } = await requestClient.indices.exists({
                index: "custom-styles"
            });

            if (index_exists === false) {
                await requestClient.indices.create({
                    index: "custom-styles",
                    body: {
                        mappings: {
                            properties: {
                                timestamp: {
                                    type: "date"
                                },
                                application: {
                                    type: "keyword"
                                },
                                user: {
                                    type: "keyword"
                                },
                                role: {
                                    type: "keyword"
                                },
                                css: {
                                    type: "text"
                                },
                                name: {
                                    type: "keyword"
                                },
                                descripion: {
                                    type: "text"
                                },
                            }
                        }
                    }
                })
            }

            return response.ok({
                body: {
                    reponse: index_exists,
                },
            });
        }
    );
}