import { IRouter } from '../../../../src/core/server';

export function registerGetTableRoute(router: IRouter) {
    router.get(
        {
            path: '/api/custom_styles/get_table',
            validate: {
            },
        },
        async (context, request, response) => {

            const requestClient = context.core.elasticsearch.client.asCurrentUser;

            const { body: result } = await requestClient.search({
                index: "custom-styles"
            });

            console.log(result.hits.hits);

            return response.ok({
                body: {
                    reponse: result.hits.hits,
                },
            });
        }
    );
}