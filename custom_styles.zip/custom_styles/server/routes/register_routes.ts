import { IRouter } from 'kibana/server';
import { registerCheckIndexRoute } from './check_index';
import { registerGetTableRoute } from './get_table';

export function registerRoutes(router: IRouter) {
    registerCheckIndexRoute(router);
    registerGetTableRoute(router);
}