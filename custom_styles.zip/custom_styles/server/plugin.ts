import {
  PluginInitializerContext,
  CoreSetup,
  CoreStart,
  Plugin,
  Logger,
} from '../../../src/core/server';

import { CustomStylesPluginSetup, CustomStylesPluginStart } from './types';
import { registerRoutes } from './routes';

export class CustomStylesPlugin
  implements Plugin<CustomStylesPluginSetup, CustomStylesPluginStart> {
  private readonly logger: Logger;

  constructor(initializerContext: PluginInitializerContext) {
    this.logger = initializerContext.logger.get();
  }

  public setup(core: CoreSetup) {
    this.logger.debug('customStyles: Setup');
    const router = core.http.createRouter();

    // Register server side APIs
    registerRoutes(router);

    return {};
  }

  public start(core: CoreStart) {
    this.logger.debug('customStyles: Started');
    return {};
  }

  public stop() { }
}
