export const PLUGIN_ID = 'crud';
export const PLUGIN_NAME = 'CRUD';
