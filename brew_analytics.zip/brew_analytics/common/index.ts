export const PLUGIN_ID = 'brewAnalytics';
export const PLUGIN_NAME = 'Brew Analytics';
