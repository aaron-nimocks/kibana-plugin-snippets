// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface BrewAnalyticsPluginSetup {}
// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface BrewAnalyticsPluginStart {}
